/// Klases Date metožu realizācijas
/// (C) Copyright 1992-2003 by Deitel & Associates, Inc. and
///Prentice Hall. All Rights Reserved.
/// Autors: Uldis Straujums - papildināts  klases Date kods no
/// Deitel & Associates, Inc. and Prentice Hall

/// constructor confirms proper value for month; calls
/// utility function checkDay to confirm proper value for day
#include<iostream>
#include"Date.h"
using namespace std;
Date::Date( int mn, int dy, int yr )
{
   if (mn > 0 && mn <= 12)  /// validate the month
      month = mn;

   else {                     /// invalid month set to 1
      month = 1;
      cout << "Month " << mn << " invalid. Set to month 1." <<endl;
   }

   year = yr;                 /// should validate yr (not implemented!)
   day = checkDay(dy);        /// validate the day

   /// output Date object to show when its constructor is called
   cout << "Date object constructor for date at address: " << this << ' ';
   print();
   cout << endl;
}
Date::Date(const Date &d) /// copy constructor
{
    month = d.month;
    day   = d.day;
    year  = d.year;
    cout << "Date object constructor for date at address: " << this << ' ';
    print();
    cout << endl;
}
/// print Date object in form month/day/year
void Date::print() const
{
   cout << month << '/' << day << '/' << year<< endl;
   cout << endl;

}

/// output Date object to show when its destructor is called
Date::~Date()
{
   cout << "Date object destructor for date at address: "<< this << ' ';
   print();
   cout << endl;

}

/// utility function to confirm proper day value based on
/// month and year; handles leap years, too
int Date::checkDay(int testDay) const
{
   static const int daysPerMonth[13] =
      {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

   /// determine whether testDay is valid for specified month
   if (testDay > 0 && testDay <= daysPerMonth[month])
      return testDay;

   /// February 29 check for leap year
   if (month == 2 && testDay == 29 &&
      (year % 400 == 0 ||
         (year % 4 == 0 && year % 100 != 0)))
      return testDay;

   cout << "Day " << testDay << " invalid. Set to day 1."<<endl;

   return 1;  /// leave object in consistent state if bad value

}
/**************************************************************************
 * (C) Copyright 1992-2003 by Deitel & Associates, Inc. and Prentice      *
 * Hall. All Rights Reserved.                                             *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
