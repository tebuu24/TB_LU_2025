/// Date klases deklarācija
/// (C) Copyright 1992-2003 by Deitel & Associates, Inc. and
///Prentice Hall. All Rights Reserved.
/// Autors: Uldis Straujums - papildināts  klases Date kods no
/// Deitel & Associates, Inc. and Prentice Hall
/**
 Klase Date(Datums), kas apraksta datumu.
 Iespējamās darbības:
  print() - izdrukā datumu
**/
class Date {

public:
   Date(int day = 1, int month = 1, int year = 1900); /// constructor with default values
   Date(const Date &d); /// copy constructor
   void print() const;  /// print date in month/day/year format
   ~Date();  /// provided to confirm destruction order

private:
   int month;  /// 1-12 (January-December)
   int day;    /// 1-31 based on month
   int year;   /// any year

   /// utility function to test proper day for month and year
   int checkDay(int) const;

}; /// end class Date
